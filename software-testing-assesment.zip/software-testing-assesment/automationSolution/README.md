There were 2 systems to test (Flight booking and Checkout functionality)

I decided to go with checkout functionality


I used Java as coding language and maven to manage packages.

The test cases can be ran on multiple browsers with chrome being the default if browser is not specified