SELECT EXTRACT(year FROM order_date)AS order_year,
COUNT(order_id) AS total_orders
FROM orders
GROUP BY EXTRACT(year FROM order_date);



