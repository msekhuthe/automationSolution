SELECT AVG(reports_to) AS average_reports
FROM employees;

SELECT COUNT(employee_id) AS higer_than_AVG 
FROM Employees 
WHERE reports_to >3.12